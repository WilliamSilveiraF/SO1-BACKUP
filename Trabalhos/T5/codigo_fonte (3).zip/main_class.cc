#include "main_class.h"

__BEGIN_API

Thread *Main::ping_pong_threads[5];
Semaphore *Main::sem;

__END_API
